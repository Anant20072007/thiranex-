# Anant Shukla — Personal Portfolio

A responsive full-stack portfolio website built with **HTML, CSS, JavaScript, Python Flask, and SQLite**.

## Features
- Responsive dark-themed portfolio
- About, skills, projects, and experience sections
- Contact form with server-side validation
- Contact messages saved in a local SQLite database
- Flask health-check endpoint at `/health`

## 1. Requirements
- Python 3.10 or newer
- pip

## 2. Open the project
Extract the ZIP file and open the `personal_portfolio` folder in VS Code (or any code editor).

## 3. Create a virtual environment

**Windows (PowerShell):**
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:
```cmd
py -m venv venv
venv\Scripts\activate
```

## 4. Install dependencies
```bash
pip install -r requirements.txt
```

## 5. Run the website
```bash
python app.py
```

Open this address in your browser:
`http://127.0.0.1:5000`

The SQLite database (`portfolio.db`) is created automatically when the app starts.

## 6. Customize your portfolio
Open `templates/index.html` and update:
- Your introduction and About section
- Skills and technologies
- Education and experience details
- Project descriptions

In `app.py`, update the `PROJECTS` list with your real projects and GitHub links. Replace `link: "#"` with the correct repository URL when available.

## 7. View saved contact messages
Install a SQLite viewer extension in VS Code, open `portfolio.db`, and inspect the `messages` table. Do not expose this database publicly.

## Deployment notes
For production:
1. Set a strong secret key using an environment variable instead of the development key in `app.py`.
2. Turn off Flask debug mode.
3. Use a persistent database/storage option. The local SQLite file may not persist on some hosting platforms.
4. Configure a production WSGI server such as Gunicorn.
5. Add your real domain and HTTPS.

This starter project is intended for learning and portfolio use. Review and customize all personal details before publishing.
