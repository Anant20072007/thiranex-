from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-deployment"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "portfolio.db"

PROJECTS = [
    {
        "name": "Product Hub",
        "tag": "Full-Stack Marketplace",
        "description": "An OLX-inspired marketplace concept where users can list pre-owned products, browse listings, and connect with sellers.",
        "stack": ["Python", "FastAPI", "Streamlit", "PostgreSQL"],
        "link": "#"
    },
    {
        "name": "Personal Portfolio",
        "tag": "Web Development",
        "description": "A responsive portfolio website to present my skills, projects, learning journey, and contact information.",
        "stack": ["HTML", "CSS", "JavaScript", "Flask", "SQLite"],
        "link": "#"
    },
    {
        "name": "Weapon Detection System",
        "tag": "Computer Vision",
        "description": "A learning project exploring object detection using computer vision tools and the YOLO framework.",
        "stack": ["Python", "OpenCV", "YOLO"],
        "link": "#"
    }
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                subject TEXT,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

@app.route("/")
def home():
    return render_template("index.html", projects=PROJECTS)

@app.route("/contact", methods=["POST"])
def contact():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    subject = request.form.get("subject", "").strip()
    message = request.form.get("message", "").strip()

    if not all([name, email, message]):
        flash("Please fill in your name, email, and message.", "error")
        return redirect(url_for("home") + "#contact")

    if len(name) > 100 or len(email) > 150 or len(subject) > 150 or len(message) > 3000:
        flash("One or more fields are too long. Please shorten your message.", "error")
        return redirect(url_for("home") + "#contact")

    with get_db() as conn:
        conn.execute(
            "INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
            (name, email, subject, message)
        )

    flash("Thanks for reaching out! Your message has been saved.", "success")
    return redirect(url_for("home") + "#contact")

@app.route("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
